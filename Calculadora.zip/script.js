function displaynum(n1) {
  Calculator.text1.value = Calculator.text1.value + n1; 
}